$setting = setting_get('huux_os_set');	
$header['keywords'] = $setting['site_keywords']; 