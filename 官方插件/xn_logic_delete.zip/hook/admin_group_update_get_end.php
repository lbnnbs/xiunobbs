$input['allowharddelete'] = form_checkbox('allowharddelete', $_group['allowharddelete']);
		