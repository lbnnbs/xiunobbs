<?php
exit;

haya_post_attach_downloads($aid);

?>