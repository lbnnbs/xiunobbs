if($check_result) {}
else{