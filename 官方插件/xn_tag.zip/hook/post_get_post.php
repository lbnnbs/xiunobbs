<?php exit;
		// todo:
		$tagids = tag_thread_find_tagid_by_tid($tid, $forum['tagcatelist']);
?>