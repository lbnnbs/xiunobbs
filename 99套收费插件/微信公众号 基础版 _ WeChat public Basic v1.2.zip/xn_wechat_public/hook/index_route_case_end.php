<?php exit;
    case 'wxlogin': include _include(APP_PATH.'plugin/xn_wechat_public/route/login.php'); break;
?>