<?php
!defined('DEBUG') AND exit('Forbidden');

setting_delete('ss_ttk');