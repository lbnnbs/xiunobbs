
// 编辑信息
post__update($pid, array('haya_edit_uid' => $uid, 'haya_edit_time' => time(), 'haya_edit_ip' => $longip));
