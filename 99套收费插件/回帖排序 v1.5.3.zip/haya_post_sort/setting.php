<?php

defined('DEBUG') OR exit('Forbidden');

$header['title'] = '回帖排序';

include _include(APP_PATH . 'plugin/haya_post_sort/htm/setting.htm');

?>
