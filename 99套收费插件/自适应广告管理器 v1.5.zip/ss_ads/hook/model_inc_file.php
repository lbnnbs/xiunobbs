
APP_PATH.'plugin/ss_ads/model/ss_ads.func.php',