<?php

function sms_ztsms_send_code($tomobile, $code, $username, $password, $productid, $sign) {

    $message = "【{$sign}】您的验证码：{$code}，该验证码5分钟内有效。";

    try {

        $url = "http://www.ztsms.cn/sendSms.do?username={$username}&password={$password}&mobile={$tomobile}&content={$message}&dstime=&productid={$productid}&xh=";

        $resp = http_get($url);

        if ($resp) {
            if (strpos($resp, "1,") !== false) {
                xn_log(print_r($resp, 1), 'sms_success');
                return true;
            } else {
                xn_log(print_r($resp, 1), 'sms_error');
            }
        } else {
            xn_log('network fail', 'sms_error');
        }

        return false;
        
    } catch (Exception $e) {
        xn_log($e->getMessage(), 'sms_error');
        return FALSE;
    }
}

?>