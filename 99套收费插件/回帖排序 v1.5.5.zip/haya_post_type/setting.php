<?php

defined('DEBUG') OR exit('Forbidden');

$header['title'] = '帖子查看方式';

include _include(APP_PATH . 'plugin/haya_post_type/htm/setting.htm');

?>
