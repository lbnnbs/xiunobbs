<?php
exit;

$s .= "<span class='text-grey'>(".humansize($attach['filesize']).", 下载次数: ".intval($attach['downloads']).")</span>";

?>
