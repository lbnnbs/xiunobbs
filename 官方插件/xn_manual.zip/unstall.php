<?php

/*
	Xiuno BBS 4.0 插件实例：在线手册
	admin/plugin-unstall-xn_manual.htm
*/

!defined('DEBUG') AND exit('Forbidden');

 setting_delete('xn_ad_setting');

?>