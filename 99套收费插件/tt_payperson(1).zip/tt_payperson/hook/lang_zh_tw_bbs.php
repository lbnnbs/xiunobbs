'charge'=>'充值',
'value_'=>'金額 (單位:分)',
'willcharge'=>'將充值',