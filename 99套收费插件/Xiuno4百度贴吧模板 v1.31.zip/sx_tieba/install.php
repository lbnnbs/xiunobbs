<?php
!defined('DEBUG') AND exit('Forbidden');

# by Shower  imyoy.com

?>