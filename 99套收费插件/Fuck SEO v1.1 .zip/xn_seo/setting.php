<?php

/*
	Xiuno BBS 4.0 插件：FUCK SEO
	作者: 倚楼观天象
*/

!defined('DEBUG') AND exit('Access Denied.');

$_TP = APP_PATH.'plugin/xn_seo/htm/';

include _include($_TP.'setting.htm');