<?php

defined('DEBUG') OR exit('Forbidden');

include _include(APP_PATH . 'plugin/haya_admin_nav/htm/setting.htm');
