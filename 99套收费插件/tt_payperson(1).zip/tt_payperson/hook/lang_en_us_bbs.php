'charge'=>'Charge',
'value_'=>'Value (CNY Cent):',
'willcharge'=>'It will cost you ',