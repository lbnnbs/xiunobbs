case 'tt_gift': include APP_PATH.'plugin/tt_gift/setting.php'; break;
case 'tt_gift_out': include APP_PATH.'plugin/tt_gift/out.php'; break;