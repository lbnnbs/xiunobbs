$kv = kv_get('sg_group');
user__update($uid, array('credits-'=>$kv['group2']));
