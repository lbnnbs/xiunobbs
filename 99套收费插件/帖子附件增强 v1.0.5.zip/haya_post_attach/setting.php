<?php

defined('DEBUG') OR exit('Forbidden');

include _include(APP_PATH . 'plugin/haya_post_attach/htm/setting.htm');

?>
