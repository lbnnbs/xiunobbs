'wechat_setting'=>'WeChat public Settings',
'wechat_menu'=>'WeChat public menu to set',
'wechat_menu_push'=>'Push the menu',

