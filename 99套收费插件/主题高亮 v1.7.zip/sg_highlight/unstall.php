<?php
/*
	Xiuno BBS 4.0 主题高亮
	插件由查鸽信息网制作网址：http://cha.sgahz.net/
*/
!defined('DEBUG') AND exit('Forbidden');
kv_delete('sg_highlight');
?>