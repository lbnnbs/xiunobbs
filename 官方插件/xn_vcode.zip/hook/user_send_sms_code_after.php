if($r === TRUE) {
	unset($_SESSION['vcode']);
}